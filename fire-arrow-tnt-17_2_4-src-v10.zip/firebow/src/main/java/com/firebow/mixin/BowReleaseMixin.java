package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.util.InteractionUtil;
import com.firebow.util.InventoryUtil;
import com.firebow.util.PlacementCalc;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * HT1 pre-charge: bắt đúng lúc thả chuột phải khi giương cung.
 * Tính quỹ đạo mũi tên từ lực kéo + vị trí/velocity player, rồi đặt rail + cart
 * ngay, không đợi mũi tên xuất hiện ở client (thường trễ vài tick do packet spawn).
 */
@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerInteractionManager.class)
public class BowReleaseMixin {

    private static final double DEG = Math.PI / 180.0;

    @Inject(method = "stopUsingItem", at = @At("HEAD"))
    private void firebow$onRelease(PlayerEntity player, CallbackInfo ci) {
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled() || rt.isBusy()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || player != mc.player) return;

        ItemStack bow = player.getActiveItem();
        if (!bow.isOf(Items.BOW)) return;
        if (!hasFlame(mc, bow)) return;
        if (!hasArrow(player)) return;

        float pull = pullProgress(player.getItemUseTime());
        if (pull < 0.1F) return;  // vanilla không bắn khi kéo quá nhẹ

        // Công thức spawn + velocity của vanilla BowItem / ProjectileEntity.setVelocity
        Vec3d start = new Vec3d(player.getX(), player.getEyeY() - 0.1, player.getZ());
        double speed = pull * 3.0;
        float yaw = player.getYaw();
        float pit = player.getPitch();
        Vec3d dir = new Vec3d(
            -Math.sin(yaw * DEG) * Math.cos(pit * DEG),
            -Math.sin(pit * DEG),
             Math.cos(yaw * DEG) * Math.cos(pit * DEG)
        );
        Vec3d pv  = player.getVelocity();
        Vec3d vel = new Vec3d(
            dir.x * speed + pv.x,
            dir.y * speed + (player.isOnGround() ? 0.0 : pv.y),
            dir.z * speed + pv.z
        );

        BlockPos railPos = PlacementCalc.predictLandingRailPos(mc.world, start, vel);
        if (railPos == null) return;

        // Cùng điều kiện reach như đường arrow-tick
        if (!InteractionUtil.inReachFrom(player.getEyePos(), railPos)) return;

        rt.requestRailPredicted(mc, railPos);
    }

    /** Giống BowItem.getPullProgress: t/20 → (f² + 2f)/3, tối đa 1. */
    private static float pullProgress(int useTicks) {
        float f = useTicks / 20.0F;
        f = (f * f + f * 2.0F) / 3.0F;
        return Math.min(f, 1.0F);
    }

    private static boolean hasFlame(MinecraftClient mc, ItemStack bow) {
        var flame = mc.world.getRegistryManager()
            .get(RegistryKeys.ENCHANTMENT)
            .getEntry(Enchantments.FLAME);
        return flame.isPresent() && EnchantmentHelper.getLevel(flame.get(), bow) > 0;
    }

    private static boolean hasArrow(PlayerEntity player) {
        var inv = player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(Items.ARROW)) return true;
        }
        return false;
    }
}
