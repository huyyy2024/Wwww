package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * InteractionUtil v7.
 *
 * Fix v7: đổi slot phải báo SERVER (UpdateSelectedSlotC2SPacket) TRƯỚC khi interact.
 * Bản cũ chỉ set selectedSlot phía client → server vẫn đọc slot cũ (bow)
 * → rail/cart bị server revert hoặc không spawn → phải retry → chậm + lỗi.
 */
public final class InteractionUtil {
    private InteractionUtil() {}

    public enum Result { SENT, NOT_READY, INVALID }

    public static void prepareRailPlacement(MinecraftClient mc, BlockPos railPos) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        RotationUtil.setPendingTarget(p, RotationUtil.calcHitVec(railPos.down(), Direction.UP));
    }

    public static Result executeRail(MinecraftClient mc, BlockPos railPos, int railSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return Result.INVALID;

        // Đang kéo cung: đổi slot lúc này làm server hủy bắn cung
        if (p.isUsingItem()) return Result.NOT_READY;

        BlockPos ground = railPos.down();
        if (!mc.world.getBlockState(railPos).isAir())      return Result.INVALID;
        if (!PlacementCalc.isSolidGround(mc.world, ground)) return Result.INVALID;

        // Knockback có thể đẩy player ra xa giữa tick arrow và tick này
        if (!inReach(p, railPos)) return Result.NOT_READY;

        // Movement packet tick này phải đã mang góc đúng
        if (!RotationUtil.wasApplied()) return Result.NOT_READY;

        Vec3d hitVec = RotationUtil.calcHitVec(ground, Direction.UP);

        int origSlot = p.getInventory().selectedSlot;
        useSlot(mc, p, railSlot);
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, ground, false));
        useSlot(mc, p, origSlot);

        RotationUtil.restoreAfterInteract(p);
        return Result.SENT;
    }

    // ─── Cart ────────────────────────────────────────────────────────────────

    public static boolean placeCartDirect(MinecraftClient mc, BlockPos railPos, int cartSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;
        if (p.isUsingItem()) return false;

        Vec3d eye     = p.getEyePos();
        Vec3d vel     = p.getVelocity();
        double vy     = p.isOnGround() ? vel.y : (vel.y - 0.08) * 0.98;
        Vec3d eyeNext = eye.add(vel.x, vy, vel.z);
        Vec3d center  = Vec3d.ofCenter(railPos);

        double distCur  = eye.squaredDistanceTo(center);
        double distNext = eyeNext.squaredDistanceTo(center);
        if (Math.max(distCur, distNext) > 4.5 * 4.5) return false;

        Vec3d   hitVec   = RotationUtil.calcHitVec(railPos, Direction.UP);
        float[] rot      = RotationUtil.calcSnappedRotation(p, eyeNext, hitVec);
        float   savedYaw = p.getYaw();
        float   savedPit = p.getPitch();

        RotationUtil.applyRaw(p, rot);

        int origSlot = p.getInventory().selectedSlot;
        useSlot(mc, p, cartSlot);
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, railPos, false));
        useSlot(mc, p, origSlot);

        RotationUtil.applyRaw(p, new float[]{ savedYaw, savedPit });
        return true;
    }

    // ─── Utils ───────────────────────────────────────────────────────────────

    /**
     * Đổi slot phía client VÀ phía server. Packet gửi theo đúng thứ tự với
     * interact packet nên server đọc đúng item khi xử lý interact.
     */
    private static void useSlot(MinecraftClient mc, ClientPlayerEntity p, int slot) {
        p.getInventory().selectedSlot = slot;
        if (mc.getNetworkHandler() != null)
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    public static void abort(MinecraftClient mc) {
        RotationUtil.abort(mc == null ? null : mc.player);
    }

    public static boolean inReach(ClientPlayerEntity p, BlockPos pos) {
        return inReachFrom(p.getEyePos(), pos);
    }

    public static boolean inReachFrom(Vec3d eyePos, BlockPos pos) {
        return eyePos.squaredDistanceTo(Vec3d.ofCenter(pos)) <= 4.5 * 4.5;
    }
}
