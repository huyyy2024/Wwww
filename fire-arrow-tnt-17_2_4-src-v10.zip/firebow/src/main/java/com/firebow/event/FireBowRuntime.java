package com.firebow.event;

import com.firebow.FireBowClient;
import com.firebow.util.*;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FireBowRuntime v10.
 *
 *   SEND  : interact rail (sau beforeSync)
 *   CART  : tick kế tiếp, rail đã hiện ở client → đặt TNT minecart
 *   WATCH : job rời main slot NGAY sau khi cart được gửi, nên cú bắn kế tiếp
 *           không phải chờ. Watcher kiểm tra server có giữ rail + spawn cart không:
 *             rail bị revert      → đặt lại rail + cart (nếu main slot rảnh)
 *             cart không spawn    → đặt lại cart (tối đa MAX_CART_TRIES)
 *
 * Mọi thao tác đều chạy trên main thread (arrow tick + END_CLIENT_TICK).
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    private static final long ARROW_TTL          = 3000L;
    private static final int  MAX_PLACE_ATTEMPTS = 4;
    private static final int  MAX_CART_TRIES     = 2;
    private static final int  MAX_WAIT           = 3;   // tick chờ trước khi bỏ bước hiện tại
    private static final int  MAX_JOB_TICKS      = 80;  // hết giờ cho cả job

    private enum Phase { SEND, CART, WATCH }

    private static final class RailJob {
        final BlockPos pos;
        Phase phase      = Phase.SEND;
        int   attempts   = 0;  // số lần đã gửi interact rail
        int   cartTries  = 0;  // số lần đã gửi interact cart
        int   cartsBefore = 0; // số minecart tại pos trước khi gửi cart
        int   ticks      = 0;  // tick đếm trong phase hiện tại
        int   window     = 0;  // số tick WATCH
        int   totalTicks = 0;

        RailJob(BlockPos pos) { this.pos = pos; }
    }

    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private final List<RailJob> watchers = new ArrayList<>();
    private volatile boolean enabled = true;
    private RailJob job = null;       // main slot: chỉ SEND/CART. Chỉ đọc/ghi trên main thread
    private BlockPos lastCartPos = null;
    private long     lastCartAt  = 0L;

    private FireBowRuntime() {}

    public boolean isEnabled() { return enabled; }
    public void    toggle()    { enabled = !enabled; }
    public boolean isBusy()    { return job != null; }

    public boolean isDuplicateArrow(int id) {
        Long t = acceptedArrows.get(id);
        return t != null && (System.currentTimeMillis() - t) < ARROW_TTL;
    }

    // ─── HEAD sendMovementPackets: áp góc để movement packet mang đúng rotation ──

    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        RotationUtil.applyBeforeSync(mc.player);
    }

    // ─── Nhận yêu cầu đặt rail ──────────────────────────────────────────────

    /** Bắt đầu job từ lúc thả cung (pre-charge). Không đợi mũi tên xuất hiện. */
    public void requestRailPredicted(MinecraftClient mc, BlockPos railPos) {
        if (job != null) return;
        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;
        if (InventoryUtil.findItem(Items.TNT_MINECART).isMissing()) return;
        startJob(mc, railPos);
    }

    public void requestRail(MinecraftClient mc, int arrowId, BlockPos railPos) {
        if (job != null) return;
        // Đang kéo cung lần sau → không đặt rail/cart, tránh ngắt cú bắn và kéo aim
        if (mc.player == null || mc.player.isUsingItem()) return;
        long now = System.currentTimeMillis();

        // Vị trí này đã có job đang watch hoặc vừa đặt xong → không đặt lại.
        // Bản cũ chặn MỌI yêu cầu 1.5s sau predict, kể cả khi predict lệch/fail → mất cart.
        if (isHandledRecently(railPos, now)) return;

        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;

        acceptedArrows.put(arrowId, now);
        pruneArrows(now);
        startJob(mc, railPos);
    }

    private boolean isHandledRecently(BlockPos pos, long now) {
        for (RailJob w : watchers) {
            if (w.pos.equals(pos)) return true;
        }
        return pos.equals(lastCartPos) && (now - lastCartAt) < ARROW_TTL;
    }

    private void pruneArrows(long now) {
        acceptedArrows.values().removeIf(t -> now - t >= ARROW_TTL);
    }

    private void startJob(MinecraftClient mc, BlockPos railPos) {
        job = new RailJob(railPos);
        InteractionUtil.prepareRailPlacement(mc, railPos);
    }

    // ─── END_CLIENT_TICK ─────────────────────────────────────────────────────

    public void onClientTick(MinecraftClient mc) {
        try {
            if (mc.player == null || mc.world == null) {
                job = null;
                watchers.clear();
                RotationUtil.abort(null);
                return;
            }
            if (!enabled) {
                if (job != null) abort(mc, "disabled");
                watchers.clear();
                return;
            }
            if (job != null) stepJob(mc);
            if (!watchers.isEmpty()) stepWatchers(mc);
        } finally {
            RotationUtil.endOfTick();
        }
    }

    private void stepJob(MinecraftClient mc) {
        // Người chơi bắt đầu kéo cung khác: hủy job, không đổi slot khi đang dùng item
        if (mc.player.isUsingItem()) { abort(mc, "using-item"); return; }

        RailJob j = job;
        j.ticks++;
        j.totalTicks++;
        if (j.totalTicks > MAX_JOB_TICKS) { abort(mc, "timeout"); return; }

        boolean railThere = isRail(mc, j.pos);

        switch (j.phase) {
            case SEND -> {
                if (railThere) {
                    // Rail đã có sẵn: không gửi interact nên phải xóa target đang chờ tại đây,
                    // nếu không beforeSync sẽ kéo góc nhìn về block rail mãi
                    RotationUtil.abort(mc.player);
                    enter(j, Phase.CART, 0);
                    return;
                }

                SearchResult rail = InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL);
                if (rail.isMissing()) { abort(mc, "no-rail"); return; }

                switch (InteractionUtil.executeRail(mc, j.pos, rail.slot)) {
                    case SENT      -> { j.attempts++; enter(j, Phase.CART, 0); }
                    case NOT_READY -> { if (j.ticks > MAX_WAIT) abort(mc, "rail-not-ready"); }
                    case INVALID   -> abort(mc, "rail-invalid");
                }
            }

            case CART -> {
                if (!railThere) { revert(mc, j); return; }

                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (cart.isMissing()) { abort(mc, "no-cart"); return; }

                int before = countCarts(mc, j.pos);
                if (InteractionUtil.placeCartDirect(mc, j.pos, cart.slot)) {
                    j.cartsBefore = before;
                    j.cartTries++;
                    // Gửi xong cart → nhả main slot, theo dõi ở watchers
                    enter(j, Phase.WATCH, windowTicks(mc));
                    watchers.add(j);
                    job = null;
                } else if (j.ticks > MAX_WAIT) {
                    abort(mc, "cart-not-placed");
                }
            }

            case WATCH -> { /* không xảy ra: job đã chuyển sang watchers */ }
        }
    }

    /** Theo dõi các cart đã gửi. Chạy mỗi tick, không chiếm main slot. */
    private void stepWatchers(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        // Đang kéo cung: chỉ ghi nhận cart đã spawn, không đặt lại gì để không ngắt cú bắn
        boolean drawing = mc.player.isUsingItem();
        Iterator<RailJob> it = watchers.iterator();
        while (it.hasNext()) {
            RailJob w = it.next();
            w.ticks++;

            if (!isRail(mc, w.pos)) {
                // Server revert rail → đặt lại rail + cart nếu main slot còn rảnh
                it.remove();
                if (!drawing && job == null && w.attempts < MAX_PLACE_ATTEMPTS) {
                    FireBowClient.LOGGER.debug("[FireBow] rail reverted at {}, re-place", w.pos);
                    w.totalTicks = 0;
                    job = w;
                    revert(mc, w);
                }
                continue;
            }

            if (w.ticks < w.window) continue;
            it.remove();

            if (countCarts(mc, w.pos) > w.cartsBefore) {
                lastCartPos = w.pos;
                lastCartAt  = now;
                continue;
            }

            // Rail còn nhưng cart không spawn → server từ chối cart, gửi lại cart
            if (!drawing && job == null && w.cartTries < MAX_CART_TRIES) {
                FireBowClient.LOGGER.debug("[FireBow] cart missing at {}, retry", w.pos);
                w.totalTicks = 0;
                enter(w, Phase.CART, 0);
                job = w;
            }
        }
    }

    /** Server đã revert rail → đặt lại rail (cart sẽ đặt ở bước CART), hoặc bỏ nếu hết lượt. */
    private void revert(MinecraftClient mc, RailJob j) {
        if (j.attempts >= MAX_PLACE_ATTEMPTS) { abort(mc, "reverted-max"); return; }
        FireBowClient.LOGGER.debug("[FireBow] rail reverted at {}, attempt {}", j.pos, j.attempts);
        InteractionUtil.prepareRailPlacement(mc, j.pos);
        enter(j, Phase.SEND, 0);
    }

    private static void enter(RailJob j, Phase phase, int window) {
        j.phase  = phase;
        j.ticks  = 0;
        j.window = window;
    }

    private void abort(MinecraftClient mc, String why) {
        FireBowClient.LOGGER.debug("[FireBow] job abort: {}", why);
        job = null;
        InteractionUtil.abort(mc);
    }

    private static boolean isRail(MinecraftClient mc, BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return s.isOf(Blocks.RAIL) || s.isOf(Blocks.POWERED_RAIL);
    }

    private static int countCarts(MinecraftClient mc, BlockPos pos) {
        Box box = Box.of(Vec3d.ofCenter(pos), 1.2, 2.0, 1.2);
        return mc.world.getEntitiesByClass(TntMinecartEntity.class, box, e -> true).size();
    }

    /** Ping/50ms + 2 tick đệm: khoảng theo dõi để phát hiện revert / cart không spawn. */
    private static int windowTicks(MinecraftClient mc) {
        long ping = PingUtil.getPingMs(mc);
        return (int) Math.max(2, Math.ceil(ping / 50.0) + 2);
    }
}
